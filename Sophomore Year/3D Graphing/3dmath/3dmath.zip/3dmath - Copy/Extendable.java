/**
 * Extendable.java  7/27/2008
 *
 * @author - Jane Doe
 * @author - Period n
 * @author - Id nnnnnnn
 *
 * @author - I received help from ...
 *
 */
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.text.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import sun.audio.*;

public class Extendable extends variables implements objectproperties
{
	Color t=Color.black;
    public void rotate(double x,double y,double z)
    {
    }
    public void rotateX(transform xform)
    {
    }
    public void rotateY(transform xform)
    {
    }
    public void rotateZ(transform xform)
    {
    }
	public void zoomOut()
	{
	}
	public void goback()
    {
    }
	public void zoomIn()
	{
	}
	public void draw(Graphics2D g)
	{
	}
	public void recalculate()
	{
	}
	public void setColor(Color y)
	{
		t=y;
	}
    public Extendable()
    {
    }
}