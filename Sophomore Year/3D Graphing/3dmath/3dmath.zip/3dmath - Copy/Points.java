/**
 * Points.java  7/27/2008
 *
 * @author - Jane Doe
 * @author - Period n
 * @author - Id nnnnnnn
 *
 * @author - I received help from ...
 *
 */
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.text.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import sun.audio.*;

public class Points extends singular
{
	double x=0;
	double y=0;
	double z=0;
	private double fx=0;
	private double fy=0;
	private double fz=0;
//	double zpic=0;
	double x2d=panx-screenx;
	double y2d=pany-screeny;
    public String toString()
    {
    	return "("+x+","+y+","+z+") Point";
    }
    public Points()
    {
    	this(0,0,0);
    	fx=x;fy=y;fz=z;
    }
    public Points(Points v)
    {
    	this(v.x,v.y,v.z);
    	fx=x;fy=y;fz=z;
    }
    public void rotateX(transform xform)
    {
    	rotateX(xform.getCosAngleX(),xform.getSinAngleX());
    	recalculate();
    }
    public void rotateY(transform xform)
    {
    	rotateY(xform.getCosAngleY(),xform.getSinAngleY());
    	recalculate();
    }
    public void rotateZ(transform xform)
    {
    	rotateZ(xform.getCosAngleZ(),xform.getSinAngleZ());
    	recalculate();
    }
    public Points(double x,double y,double z)
    {
    	setTo(x,y,z);
    	fx=x;fy=y;fz=z;
    }
    public void setTo(double x,double y,double z)
    {
    	this.x=x;this.y=y;this.z=z;//zpic=z+finald;
    	recalculate();
    }
    public double getx()
    {
    	return x;
    }
    public double gety()
    {
    	return y;
    }
    public double getDotProduct(Points p)
    {
    	return x*p.x+y*p.y+z*p.z;
    }
    public void setToCrossProduct(Points u,Points v)
    {
    	double x=u.y*v.z-u.z*v.y;
    	double y=u.z*v.x-u.x*v.z;
    	double z=u.x*v.y-u.y*v.x;
    	this.x=x;this.y=y;this.z=z;
    }
    public void goback()
    {
    	x=fx;y=fy;z=fz;
    	recalculate();
    }
    public double getz()
    {
    	return z;
    }
    public void zoomOut()
    {
//    	zpic++;
    	recalculate();
    }
    public void zoomIn()
    {
//    	zpic--;
    	recalculate();
    }
    public int getfakex()
    {
    	return (int)Math.round(x2d);
    }
    public int getfakey()
    {
    	return(int)Math.round(y2d);
    }
    public void recalculate()
    {
    	x2d=win2screen.convertx(x,z);
    	y2d=win2screen.converty(y,z);
    }
    public void transfer(Vector3d v)
    {
    	setTo((double)v.x,(double)v.y,(double)v.z);
    }
    public static Points change(Vector3d v)
    {
    	return new Points((double)v.x,(double)v.y,(double)v.z);
    }
    public static Points addpoints(Points p1,Points p2)
    {
    	Points temp=new Points();
    	temp.setTo(p1);
    	temp.add(p2);
    	return temp;
    }
    public void setTo(Points v)
    {
    	setTo(v.x,v.y,v.z);
    }
    public boolean equals(Object obj)
    {
    	Points v=(Points)obj;
    	return equals(v.x,v.y,v.z);
    }
    public boolean equals(double vx,double vy, double vz)
    {
    	return(vx==x&&vy==y&&vz==z);
    }
	public void add(double x2,double y2,double z2)
    {
    	setTo(x+x2,y+y2,z+z2);
    }
    public void add(Points v)
    {
    	add(v.x,v.y,v.z);
    }
    public void subtract(double x,double y,double z)
    {
    	add(-x,-y,-z);
    }
    public void subtract(Points v)
    {
    	add(-v.x,-v.y,-v.z);
    }
    public void multiply(double x2)
    {
    	setTo(x*x2,y*x2,z*x2);
    }
    public void divide(double x2)
    {
    	setTo(x/x2,y/x2,z/x2);
    }
    public double getdistance0()
	{
		return Math.sqrt(x*x+y*y+z*z);
	}
    public void draw(Graphics2D g)
    {
    	g.setColor(Color.black);
    	g.fillRect((int)Math.round(x2d),(int)Math.round(y2d),4,4);
    }
    public void rotateX(double cosAngle,double sinAngle)
    {
    	double newY=y*cosAngle-z*sinAngle;
    	double newZ=y*sinAngle+z*cosAngle;
    	y=newY;
    	z=newZ;
    }
    public void rotateY(double cosAngle,double sinAngle)
    {
    	double newZ=z*cosAngle-x*sinAngle;
    	double newX=z*sinAngle+x*cosAngle;
    	x=newX;
    	z=newZ;
    }
    public void rotateZ(double cosAngle,double sinAngle)
    {
    	double newX=x*cosAngle-y*sinAngle;
    	double newY=x*sinAngle+y*cosAngle;
    	x=newX;
    	y=newY;
    }
    //rotated then tranlated
    public void add(transform xform)
    {
    	addRotation(xform);
    	add(xform.getLocation());
    }
    public void subtract(transform xform)
    {
    	subtract(xform.getLocation());
    	subtractRotation(xform);
    }
    public void addRotation(transform xform)
    {
   		rotateX((double)xform.getCosAngleX(),(double)xform.getSinAngleX());
   		rotateY((double)xform.getCosAngleY(),(double)xform.getSinAngleY());
   		rotateZ((double)xform.getCosAngleZ(),(double)xform.getSinAngleZ());
    }
    public void subtractRotation(transform xform)
    {
    	//note that sin(-x) == -sin(x)  and  cos(-x) == cos(x)
    	rotateZ((double)xform.getCosAngleZ(),(double)-xform.getSinAngleZ());
   		rotateY((double)xform.getCosAngleY(),(double)-xform.getSinAngleY());
   		rotateX((double)xform.getCosAngleX(),(double)-xform.getSinAngleX());
    //	rotateX();
    }
}