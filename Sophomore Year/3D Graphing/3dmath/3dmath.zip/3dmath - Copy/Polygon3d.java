/**
 * Polygon3d.java  7/27/2008
 *
 * @author - Jane Doe
 * @author - Period n
 * @author - Id nnnnnnn
 *
 * @author - I received help from ...
 *
 */
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.text.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import sun.audio.*;

public class Polygon3d extends Polys
{
	Vector3d normal=new Vector3d();
    public Polygon3d()
    {
    	setColor(new Color(255/2,255,255/2));
    	numVertices=0;
    	which=1;
    }
    private int numVertices=0;
    ArrayList<Points> p=new ArrayList<Points>();
    public void setwhich(int y)
    {
    	super.set(y);
    }
    public void setColor(Color t)
    {
    	super.setColor(t);
    	for(int k=0;k<p.size();k++)
    	{
    		p.get(k).setColor(t);
    	}
    }
    public Vector3d calcNormal()
    {
    	Vector3d temp1=new Vector3d();
    	Vector3d temp2=new Vector3d();
    	temp1.setTo(Vector3d.change(p.get(2)));
    	temp1.subtract(Vector3d.change(p.get(1)));
    	temp2.setTo(Vector3d.change(p.get(0)));
    	temp2.subtract(Vector3d.change(p.get(1)));
    	normal.setToCrossProduct(temp1,temp2);
    	normal.normalize();
    	return normal;
    }
    public Vector3d getNormal()
    {
    	return normal;
    }
    public void setNormal(Vector3d v)
    {
    	normal.setTo(v);
    }
    public void setNormal(Points v)
    {
    	setNormal(Vector3d.change(v));
    }
    public boolean isFacing(Vector3d v)
    {
    	Vector3d temp1=new Vector3d();
    	temp1.setTo(v);
    	temp1.subtract(Vector3d.change(p.get(0)));
    	return normal.getDotProduct(temp1)>=0;
    }
    public boolean isFacing(Points v)
    {
    	Vector3d temp1=new Vector3d();
    	temp1.setTo(Vector3d.change(v));
    	temp1.subtract(Vector3d.change(p.get(0)));
    	return normal.getDotProduct(temp1)>=0;
    }
    public Points GetNormal()
    {
    	return Points.change(getNormal());
    }
    public Points CalcNormal()
    {
    	return Points.change(calcNormal());
    }
    public Polygon3d(Points p0,Points p1,Points p2,Points p3)
    {

    	p.add(p0);
    	p.add(p1);
    	p.add(p2);
    	p.add(p3);
    	Polygon3d(p);
    	setColor(new Color(255/2,255,255/2));
    	which=1;
    }
    public void rotateX(transform xform)
    {
    	for(int k=0;k<p.size();k++)
    	{
    		p.get(k).rotateX(xform);
    	}
    }
    public void rotateY(transform xform)
    {
    	for(int k=0;k<p.size();k++)
    	{
    		p.get(k).rotateY(xform);
    	}
    }
    public void goback()
    {
    	for(int k=0;k<p.size();k++)
    	{
    		p.get(k).goback();
    	}
    }
    public void rotateZ(transform xform)
    {
    	for(int k=0;k<p.size();k++)
    	{
    		p.get(k).rotateZ(xform);
    	}
    }
    public void add(Points p)
    {
    	this.p.add(p);
    }
    public Polygon3d(Points p0,Points p1,Points p2)
    {

    	p.add(p0);
    	p.add(p1);
    	p.add(p2);
    	Polygon3d(p);
    	setColor(new Color(255/2,255,255/2));
    	which=1;
    }
    public void showpoints(boolean t)
    {
    	set(t);
    }
    public Polygon3d(ArrayList<Points> p)
    {
    	Polygon3d(p);
    	setColor(new Color(255/2,255,255/2));
    	which=1;
    }
    private void Polygon3d(ArrayList<Points> p)
    {
    	this.p=(ArrayList<Points>)p.clone();
    	for(int k=0;k<p.size();k++)
    	{
    		p.get(k).setColor(new Color(255/2,255,255/2));
    	}
    	numVertices=p.size();
    	which=1;
    }
    public void setTo(Polygon3d poly)
    {
    	numVertices=poly.numVertices;
    	ensureCapacity(numVertices);
    	for(int k=0;k<numVertices;k++)
    	{
    		p.get(k).setTo(poly.p.get(k));
    	}
    }
    protected void ensureCapacity(int length)
    {
    	if(p.size()<length)
    	{
    		for(int k=0;k<length-p.size();k++)
    		{
    			p.add(new Points());
    		}
    	}
    }
    public void recalculate()
    {
    	for(int k=0;k<p.size();k++)
    	{
    	//	System.out.println("recalulating2");
    		p.get(k).recalculate();
    	}
    	calcNormal();
    }
    public int getNumVerts()
    {
    	return numVertices;
    }
    public Points getVertex(int index)
    {
		return p.get(index);
    }
    public void draw1(Graphics2D g)
    {
		for(int k=0;k<p.size()-1;k++)
    	{
    		g.setColor(t);
    		g.drawLine(p.get(k).getfakex(),p.get(k).getfakey(),p.get(k+1).getfakex(),p.get(k+1).getfakey());
    		if(points)
    		{
    			p.get(k).draw(g);
    		}
    	}
    	g.setColor(t);
    	g.drawLine(p.get(p.size()-1).getfakex(),p.get(p.size()-1).getfakey(),p.get(0).getfakex(),p.get(0).getfakey());
    	if(points)
    	{
    		p.get(p.size()-1).draw(g);
    		p.get(0).draw(g);
    	}
    }
    public void zoomOut()
    {
    	for(int k=0;k<p.size();k++)
    	{
    		p.get(k).zoomOut();
    	}
    }
    public void zoomIn()
    {
    	for(int k=0;k<p.size();k++)
    	{
    		p.get(k).zoomIn();
    	}
    }
    public void drawVerts(Graphics2D g)
    {
    	for(int k=0;k<p.size();k++)
    	{
    		p.get(k).draw(g);
    	}
    }
}