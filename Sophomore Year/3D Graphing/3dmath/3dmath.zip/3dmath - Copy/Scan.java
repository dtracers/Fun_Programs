/**
 * Scan.java  7/29/2008
 *
 * @author - Jane Doe
 * @author - Period n
 * @author - Id nnnnnnn
 *
 * @author - I received help from ...
 *
 */
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.text.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import sun.audio.*;

public class Scan
{
	public int left;
	public int right;
    public Scan()
    {
    }
    public static int ceil(float f)
    {
    	if(f>0)
    	{
    		return (int)f+1;
    	}else
    		return (int)f;
    }
    public void setBoundary(int x)
    {
    	if(x<left)
    	{
    		left=x;
    	}
    	if(x-1>right)
    	{
    		right=x-1;
    	}
    }
	public void clear()
	{
		left=Integer.MAX_VALUE;
		right=Integer.MIN_VALUE;
	}
	public boolean isValid()
	{
		return left<=right;
	}
	public void setTo(int l,int r)
	{
		left=l;right=r;
	}
	public boolean equals(int l,int r)
	{
		return (left==l&&right=r);
	}
}