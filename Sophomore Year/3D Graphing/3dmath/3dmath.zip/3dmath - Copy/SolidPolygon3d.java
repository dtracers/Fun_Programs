/**
 * SolidPolygon3d.java  7/28/2008
 *
 * @author - Jane Doe
 * @author - Period n
 * @author - Id nnnnnnn
 *
 * @author - I received help from ...
 *
 */
import java.awt.*;
import java.awt.geom.GeneralPath;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.text.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import sun.audio.*;

public class SolidPolygon3d extends Polygon3d
{
    public SolidPolygon3d()
    {
    	super();
    	which=3;
    }
    public SolidPolygon3d(Points p0,Points p1,Points p2,Points p3)
    {
    	super(p0,p1,p2,p3);
    	which=3;
    }
    public SolidPolygon3d(Points p0,Points p1,Points p2)
    {
    	super(p0,p1,p2);
    	which=3;
    }
    public SolidPolygon3d(ArrayList<Points> p)
    {
    	super(p);
    	which=3;
    }
    public void fill(Graphics2D g)
	{
		GeneralPath path=new GeneralPath();
		path.moveTo(p.get(0).getfakex(),p.get(0).getfakey());
		for(int k=1;k<p.size();k++)
		{
		//	System.out.println(k+" the num of vertex");
			path.lineTo(p.get(k).getfakex(),p.get(k).getfakey());
		}
		g.setColor(t);
	//	System.out.println(path);
		g.fill(path);
	}
	public void fillVerts(Graphics2D g)
	{
		for(int k=0;k<p.size();k++)
    	{
    		for(int q=0;q<p.size();q++)
    		{
    			if(k!=q)
    			{
    				g.setColor(t);
	    			g.drawLine(p.get(k).getfakex(),p.get(k).getfakey(),p.get(q).getfakex(),p.get(q).getfakey());

    			}
    		}
    		if(points)
    		{
    			p.get(k).draw(g);
    		}
    	}
	}
}