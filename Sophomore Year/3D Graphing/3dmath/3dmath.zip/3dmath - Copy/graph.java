/**
 * graph.java  7/26/2008
 *
 * @author - Jane Doe
 * @author - Period n
 * @author - Id nnnnnnn
 *
 * @author - I received help from ...
 *
 */
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.text.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import sun.audio.*;

public class graph extends staticgraph implements objectproperties
{
	transform form=new transform(0,0,0);
    public graph()
    {
    	form.rotateAngleY(.01);
    	form.rotateAngleX(.01);
    	form.rotateAngleZ(.01);
    }
    public graph(double x1,double y1,double z1)
    {
    	super(x1,y1,z1);
    }
    public void rotate(double x,double y,double z)
    {
    }
	public void zoomout(double x,double y,double z)
	{
	}
	public void panupdown(boolean t)//t if true down
	{
		if(t)
			variables.pany++;
		else
			variables.pany--;
	}
	public void panleftright(boolean t)//t if true right
	{
		if(t)
			panx++;
		else
			panx--;
	}
	public void goback()
	{
		panx=fpanx;pany=fpany;panz=fpanz;
		for(int k=0;k<objects.size();k++)
		{
			objects.get(k).goback();
		}
	}
	public void rotatey()
	{
		for(int k=0;k<objects.size();k++)
		{
			objects.get(k).rotateY(form);
		}
	}
	public void rotatex()
	{
		for(int k=0;k<objects.size();k++)
		{
			objects.get(k).rotateX(form);
		}
	}
	public void rotatez()
	{
		for(int k=0;k<objects.size();k++)
		{
			objects.get(k).rotateZ(form);
		}
	}
	public void drawgraph(Graphics2D g)
	{
		if(!(oldxcamera==xcamera&&oldpanx==panx&&
		oldycamera==ycamera&&oldpany==pany&&
		oldzcamera==zcamera&&oldpany==pany&&oldd==distance))
		{
			oldxcamera=xcamera;oldpanx=panx;
			oldycamera=ycamera;oldpany=pany;
			oldzcamera=zcamera;oldpany=pany;oldd=distance;
			for(int k=0;k<objects.size();k++)
			{
			//	System.out.println("recalculateing");
				objects.get(k).recalculate();
			}
		}
		Random rand=new Random();
		for(int k=0;k<objects.size();k++)
		{
			Color t=new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255));
			g.setColor(t);
			objects.get(k).draw(g);
		}
	}
}