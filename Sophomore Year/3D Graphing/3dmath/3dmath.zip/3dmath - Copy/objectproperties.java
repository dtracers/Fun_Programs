/**
 * objectproperties.java  7/26/2008
 *
 * @author - Jane Doe
 * @author - Period n
 * @author - Id nnnnnnn
 *
 * @author - I received help from ...
 *
 */

import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.text.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import sun.audio.*;

public interface objectproperties
{
	public void rotate(double x,double y,double z);
	public void zoomOut();
	public void zoomIn();
	public void draw(Graphics2D g);
}