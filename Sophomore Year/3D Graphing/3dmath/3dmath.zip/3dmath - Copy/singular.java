/**
 * singular.java  7/27/2008
 *
 * @author - Jane Doe
 * @author - Period n
 * @author - Id nnnnnnn
 *
 * @author - I received help from ...
 *
 */
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.text.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import sun.audio.*;

public class singular extends Extendable
{
	public int getfakex()
	{
		return 0;
	}
	public int getfakey()
	{
		return 0;
	}
	public double getdistance0()
	{
		return 0;
	}
}