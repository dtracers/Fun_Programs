/**
 * staticgraph.java  7/27/2008
 *
 * @author - Jane Doe
 * @author - Period n
 * @author - Id nnnnnnn
 *
 * @author - I received help from ...
 *
 */
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.text.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import sun.audio.*;

public class staticgraph extends variables implements objectproperties
{
	double xsize=100;
	double ysize=100;
	double zsize=100;
	ArrayList<Extendable> objects=new ArrayList<Extendable>();
    public staticgraph()
    {
    	add();

    }
    public void add()
    {
    	objects.add(new Points());//0,0,0 ///1

    	objects.add(new Points(0,xsize,0));//0,100,0 ///2
    	objects.add(new Points(0,-xsize,0));//0,-100,0 ///3

    	objects.add(new Points(ysize,0,0));//100,0,0 ///4
    	objects.add(new Points(-ysize,0,0));//-100,0,0 ///5

		objects.add(new Points(ysize,xsize,0));//100,100,0 ///16
    	objects.add(new Points(ysize,-xsize,0));//100,-100,0 ///17
    	objects.add(new Points(-ysize,xsize,0));//-100,100,0 ///18
    	objects.add(new Points(-ysize,-xsize,0));//-100,-100,0 ///19

    	objects.add(new Points(0,0,zsize));//0,0,100 ///6
    	objects.add(new Points(0,0,-zsize));//0,0,-100 ///7

    	objects.add(new Points(0,xsize,zsize));//0,100,100 ///8
    	objects.add(new Points(0,xsize,-zsize));//0,100,-100 ///9
    	objects.add(new Points(0,-xsize,zsize));//0,-100,100 ///10
    	objects.add(new Points(0,-xsize,-zsize));//0,-100,-100 ///11

    	objects.add(new Points(ysize,0,zsize));//100,0,100 ///12
    	objects.add(new Points(ysize,0,-zsize));//100,0,-100 ///13
    	objects.add(new Points(-ysize,0,zsize));//-100,0,100 ///14
    	objects.add(new Points(-ysize,0,-zsize));//-100,0,-100 ///15



    	objects.add(new Points(ysize,xsize,zsize));//100,100,100 ///20
    	objects.add(new Points(ysize,-xsize,zsize));//100,-100,100 ///21

    	objects.add(new Points(ysize,xsize,-zsize));//100,100,-100 ///22
    	objects.add(new Points(ysize,-xsize,-zsize));//100,-100,-100 ///23

    	objects.add(new Points(-ysize,xsize,zsize));//-100,100,100 ///24
    	objects.add(new Points(-ysize,-xsize,zsize));//-100,-100,100 ///25

    	objects.add(new Points(-ysize,xsize,-zsize));//-100,100,-100 ///26
    	objects.add(new Points(-ysize,-xsize,-zsize));//-100,-100,-100 ///27

    	objects.add(new Ray3d(new Points(0,0,1),new Vector3d((float)ysize,(float)xsize,(float)zsize)));//-100,-100,-100 ///27

		Polygon3d f=new SolidPolygon3d();
		f.add(new Points(-25,0,1));
		f.add(new Points(25,0,1));
		f.add(new Points(25,150,1));
		f.add(new Points(-25,150,1));
		f.showpoints(true);
		f.setwhich(3);
		f.setColor(Color.green);
		objects.add(f);
		f=new SolidPolygon3d();
		f.add(new Points(-100,150,0));
		f.add(new Points(100,150,0));
		f.add(new Points(50,200,0));
		f.add(new Points(75,200,0));
		f.add(new Points(25,250,0));
		f.add(new Points(50,250,0));
		f.add(new Points(0,300,0));
		f.add(new Points(-50,250,0));
		f.add(new Points(-25,250,0));
		f.add(new Points(-75,200,0));
		f.add(new Points(-50,200,0));
		f.add(new Points(-100,150,0));
		f.showpoints(true);
		f.setwhich(3);
		f.setColor(Color.green);
		objects.add(f);
		f=new SolidPolygon3d();
		f.add(new Points(ysize,xsize,-zsize));
		f.add(new Points(ysize,-xsize,-zsize));
		f.add(new Points(ysize,-xsize,zsize));
		f.add(new Points(ysize,xsize,zsize));
		f.add(new Points(-ysize,xsize,zsize));
		f.add(new Points(-ysize,-xsize,zsize));
		f.add(new Points(-ysize,-xsize,-zsize));
		f.add(new Points(-ysize,xsize,-zsize));
		f.showpoints(true);
		f.setwhich(4);
		f.setColor(Color.blue);
		objects.add(f);
    }
    public void order()
    {

    }
    public staticgraph(double x1,double y1,double z1)
    {
    	xsize=x1;ysize=y1;zsize=z1;
		add();
    }
    public void rotate(double x,double y,double z)
    {
    }
    public void zoomIn()
	{
		panz--;
		for(int k=0;k<objects.size();k++)
		{
			objects.get(k).recalculate();
		}
	}
	public void zoomOut()
	{
		panz++;
		for(int k=0;k<objects.size();k++)
		{
			objects.get(k).recalculate();
		}
	}
	public void draw(Graphics2D g)
	{

	}
}