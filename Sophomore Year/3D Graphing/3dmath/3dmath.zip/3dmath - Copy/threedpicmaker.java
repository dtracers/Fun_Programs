import static java.lang.System.*;
import java.awt.*;
import static java.awt.Color.*;
import java.awt.event.*;
import java.awt.event.KeyEvent.*;
import java.awt.Event.*;
import java.awt.image.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.text.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import sun.audio.*;

public class threedpicmaker extends JFrame implements KeyListener,EventListener,
						MouseListener,MouseMotionListener,MouseWheelListener
{
	Image dbg,dbg2;
	Graphics g,g2;
	boolean run;
	boolean zp=false;
	boolean xp=false;
	boolean yp=false;
	boolean pp=false;
	boolean pm=false;
	boolean up=false;
	boolean down=false;
	boolean left=false;
	boolean right=false;
	boolean mouseb1=false;
	boolean mouseb2=false;
	boolean mouseb3=false;
	int sizew=1024;
	int sizeh=760;
	long delay=0,startdelay=0;
	graph gr=new graph();
	public static void main(String[] args)
    {
    	threedpicmaker v=new threedpicmaker();
    }
    public threedpicmaker()
    {
		frameInit();
		setSize(sizew,sizeh);
      	setBackground(Color.white);
      	setDefaultCloseOperation(EXIT_ON_CLOSE);
      	setVisible(true);
      	addKeyListener(this);
      	addMouseListener(this);
      	addMouseMotionListener(this);
      	addMouseWheelListener(this);
      	dbg = createImage (this.getSize().width, this.getSize().height);
      	dbg2 = createImage (this.getSize().width, this.getSize().height);
		g = dbg.getGraphics ();
		g2 = dbg2.getGraphics ();
		action1();
    }
    public void init()
    {
    }
    public void paint(Graphics g3)
    {
    	run=true;
    	g.setColor(Color.white);
    	g.fillRect(0,0,this.getSize().width, this.getSize().height);
    	gr.drawgraph((Graphics2D)g);
    	g2.drawImage(dbg,0,0,this);
    	g3.drawImage(dbg2,5,24,this);
    	action1();
    }
    public void update(Graphics g3)
    {
    	paint(g3);
    }
    public void action1()
    {
	    do
	    {
	    	boolean t=test();
	    	if(t)
			{
				if(yp)
				gr.rotatey();
				if(xp)
				gr.rotatex();
				if(zp)
				gr.rotatez();
				if(pm)
				gr.zoomIn();
				else if(pp)
				gr.zoomOut();
				if(up||down)
					gr.panupdown(down);
				if(left||right)
					gr.panleftright(right);
				action2();
			}
	    }while(run);
    }
    public void action2()
    {
    //	System.out.println("repaint");
    	repaint();
    	run=false;
    }
    public boolean test()
    {
		long endDelay=System.currentTimeMillis();
		if(startdelay+delay<=endDelay)
		{
			startdelay=System.currentTimeMillis();
			return true;
		}
		else
			return false;
    }
    public void keyPressed(KeyEvent e)
    {
    	//System.out.println(e);
    	if(e.getKeyCode()==61||e.getKeyCode()==107)
    	{
    		pp=true;
    		repaint();
    	}
    	else if(e.getKeyCode()==45||e.getKeyCode()==109)
    	{
    		pm=true;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_X)
    	{
    		xp=true;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_UP)
    	{
    		up=true;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_LEFT)
    	{
    		left=true;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_DOWN)
    	{
    		down=true;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_RIGHT)
    	{
    		right=true;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_Y)
    	{
    		yp=true;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_Z)
    	{
    		zp=true;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_B)
    	{
    		gr.goback();
    		repaint();
    	}
    }
    public void keyReleased(KeyEvent e)
    {
    	if(e.getKeyCode()==61||e.getKeyCode()==107)
    	{
    		pp=false;
    		repaint();
    	}
    	else if(e.getKeyCode()==45||e.getKeyCode()==109)
    	{
    		pm=false;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_UP)
    	{
    		up=false;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_LEFT)
    	{
    		left=false;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_DOWN)
    	{
    		down=false;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_RIGHT)
    	{
    		right=false;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_X)
    	{
    		xp=false;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_Y)
    	{
    		yp=false;
    		repaint();
    	}
    	if(e.getKeyCode()==e.VK_Z)
    	{
    		zp=false;
    		repaint();
    	}
    }
    public void keyTyped(KeyEvent e)
    {
    }
    public void mousePressed(MouseEvent e)
    {
    	if(e.getButton()==3)
    	{
    		mouseb3=true;
    	//	System.out.println(e);
    	//	System.out.println("button3 pressed");//rightclick pan
    	}else if(e.getButton()==2)
    	{
    		mouseb2=true;
    //		System.out.println(e);
    //		System.out.println("button2 pressed");//mousewheel rotate
    	}else if(e.getButton()==1)
    	{
    		mouseb1=true;
    //		System.out.println(e);
    	//	System.out.println("button1 pressed");//leftclick select
    	}
    }
    public void mouseReleased(MouseEvent e)
    {
    	if(e.getButton()==3)
    	{
    		mouseb3=false;
    	//	System.out.println(e);
    	//	System.out.println("button3 pressed");//rightclick pan
    	}else if(e.getButton()==2)
    	{
    		mouseb2=false;
    //		System.out.println(e);
    //		System.out.println("button2 pressed");//mousewheel rotate
    	}else if(e.getButton()==1)
    	{
    		mouseb1=false;
    //		System.out.println(e);
    	//	System.out.println("button1 pressed");//leftclick select
    	}
    }
    public void mouseEntered(MouseEvent e)
    {
    }
    public void mouseExited(MouseEvent e)
    {
    }
    public void mouseClicked(MouseEvent e)
    {
    }
    public void mouseDragged(MouseEvent e)
    {
    	int x=e.getX();
    	int y=e.getY();
    	if(mouseb2)
    	{
    		
    	}
    }
    public void mouseMoved(MouseEvent e)
    {
    	
    }
    public void mouseWheelMoved(MouseWheelEvent e)
    {
    	int t=e.getWheelRotation();
    	for(int k=0;k<(int)Math.abs(t*10);k++)
    	{
    		if(t<0)
    		{
    			gr.zoomOut();
    		}else
    			gr.zoomIn();
    	}
    //	System.out.println(e);
    }
}